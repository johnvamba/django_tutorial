from django.urls import path

from . import views

app_name = 'polls'
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('<uuid:pk>/', views.DetailView.as_view(), name='detail'),
    path('<uuid:pk>/results/', views.ResultView.as_view(), name='results'),
    path('<uuid:question_id>/vote/', views.vote, name='vote'),
]